import './SongGuessModal.css'
import { useEffect } from 'react';

// A modal that displays an active attempt at a full song title guess and pops up when the "Guess Song" button is pressed
export default function SongGuessModal({ randomSong, songGuess, setSongGuess, handleGuessSongSubmit, onClickX }) {
  useEffect(() => {
    if (randomSong) {
      const firstInput = document.querySelector(".interactive-blanks input:not([disabled])");
      firstInput?.focus();
    }
  }, [randomSong]);

  const exitModal = () => {
    onClickX(false);
  }

  // Handle input change for each blank
  const handleInputChange = (value, index) => {
    // Prevent non-alphanumeric input
    if (!/^[a-zA-Z0-9]$/.test(value)) return;

    const updatedGuess = [...songGuess];
    updatedGuess[index] = value.toUpperCase();
    setSongGuess(updatedGuess);

    // Automatically move to the next blank if valid input, skipping spaces
    let nextIndex = index + 1;
    while (randomSong.name[nextIndex] === " " && nextIndex < randomSong.name.length) {
      nextIndex++;
    }
    const nextInput = document.querySelector(`input:nth-child(${nextIndex + 1})`);
    nextInput?.focus();
  };

  // Handle backspace key press
  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace") {
      e.preventDefault();

      const updatedGuess = [...songGuess];

      if (updatedGuess[index]) {
        // First backspace: clear the current input
        updatedGuess[index] = "";
        setSongGuess(updatedGuess);
      } else if (index > 0) {
        // Second backspace: move focus to the previous blank and clear
        let prevIndex = index - 1;
        while (randomSong.name[prevIndex] === " " && prevIndex >= 0) {
          prevIndex--;
        }

        updatedGuess[prevIndex] = ""; // Clear previous input
        setSongGuess(updatedGuess);

        const previousInput = document.querySelector(`input:nth-child(${prevIndex + 1})`);
        previousInput?.focus();
      }
    }
  };

  // Render interactive blanks for song title guess
  const renderInteractiveBlanks = () => {
    if (!randomSong) return null;

    return (
      <div className="interactive-blanks">
        {randomSong.name.split("").map((char, index) => {
          const isSpace = char === " ";
          const guessedLetter = songGuess[index];
          const isGuessed = guessedLetter && guessedLetter.toLowerCase() === char.toLowerCase();

          return (
            <input
              id={index}
              key={index}
              className={isSpace ? "space" : "interactive-blank"}
              type="text"
              maxLength={1}
              disabled={isSpace} // Disable input for spaces
              value={guessedLetter || ""} // Show guessed letters
              placeholder={!isGuessed && !isSpace ? char.toUpperCase() : ""} // Faded placeholder for correctly guessed blanks
              onChange={(e) => handleInputChange(e.target.value, index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
            />
          );
        })}
      </div>
    );
  };

  return (
    <div className="song-guess-modal-background" onClick={exitModal}>
      <div className="song-guess-modal-content" onClick={e => e.stopPropagation()}>
        {renderInteractiveBlanks()}
        <button onClick={handleGuessSongSubmit}>
          Guess Song
        </button>
      </div>
    </div >
  )
}